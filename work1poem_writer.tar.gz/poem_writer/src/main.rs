// ============================================================================
// POEM WRITER - Intention Space Physics Implementation
// I-O-I-DN-I-GL-I Flow Pattern
// Platform: Android (Rust + Slint)
// ============================================================================

use slint::ComponentHandle;
use std::sync::{Arc, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};
use serde::{Deserialize, Serialize};

// ============================================================================
// INTENTION SPACE CORE STRUCTURES
// ============================================================================

/// Trivalent logic: Yes/No/Undecided
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum TV {
    Y,  // Yes - completed
    N,  // No - failed
    U,  // Undecided - pending
}

/// Field Pulse - Immutable data carrier in Intention Space
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FieldPulse {
    pub id: String,
    pub name: String,
    pub tv: TV,
    pub response: Vec<String>,
    pub timestamp: u64,
}

impl FieldPulse {
    pub fn new(name: &str) -> Self {
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_millis() as u64;
        
        Self {
            id: format!("{}_{}", name, timestamp),
            name: name.to_string(),
            tv: TV::U,
            response: vec![],
            timestamp,
        }
    }
    
    pub fn with_response(mut self, response: Vec<String>) -> Self {
        self.response = response;
        self
    }
    
    pub fn with_tv(mut self, tv: TV) -> Self {
        self.tv = tv;
        self
    }
}

/// Design Node - Computation locality point
pub struct DesignNode {
    pub id: String,
    pub name: String,
    pub compute: Box<dyn Fn(&[FieldPulse]) -> Vec<String> + Send + Sync>,
}

impl DesignNode {
    pub fn new<F>(id: &str, name: &str, compute: F) -> Self
    where
        F: Fn(&[FieldPulse]) -> Vec<String> + Send + Sync + 'static,
    {
        Self {
            id: id.to_string(),
            name: name.to_string(),
            compute: Box::new(compute),
        }
    }
    
    pub fn execute(&self, inputs: &[FieldPulse]) -> FieldPulse {
        let result = (self.compute)(inputs);
        FieldPulse::new(&format!("{}_result", self.id))
            .with_response(result)
            .with_tv(TV::Y)
    }
}

/// Object - Static mapping function
pub struct ObjectMapping {
    pub id: String,
    pub transform: Box<dyn Fn(&FieldPulse) -> FieldPulse + Send + Sync>,
}

impl ObjectMapping {
    pub fn new<F>(id: &str, transform: F) -> Self
    where
        F: Fn(&FieldPulse) -> FieldPulse + Send + Sync + 'static,
    {
        Self {
            id: id.to_string(),
            transform: Box::new(transform),
        }
    }
    
    pub fn apply(&self, input: &FieldPulse) -> FieldPulse {
        (self.transform)(input)
    }
}

// ============================================================================
// POEM WRITER DOMAIN MODEL
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PoemPage {
    pub id: String,
    pub page_number: usize,
    pub poem_text: String,
    pub notes_text: String,
    pub created_at: u64,
    pub updated_at: u64,
}

impl PoemPage {
    pub fn new(page_number: usize) -> Self {
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_millis() as u64;
        
        Self {
            id: format!("page_{}", page_number),
            page_number,
            poem_text: String::new(),
            notes_text: String::new(),
            created_at: timestamp,
            updated_at: timestamp,
        }
    }
    
    pub fn update_poem(&mut self, text: String) {
        self.poem_text = text;
        self.updated_at = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_millis() as u64;
    }
    
    pub fn update_notes(&mut self, text: String) {
        self.notes_text = text;
        self.updated_at = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_millis() as u64;
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PoemCollection {
    pub pages: Vec<PoemPage>,
    pub current_page: usize,
}

impl PoemCollection {
    pub fn new() -> Self {
        Self {
            pages: vec![PoemPage::new(1)],
            current_page: 0,
        }
    }
    
    pub fn add_page(&mut self) -> usize {
        let page_number = self.pages.len() + 1;
        self.pages.push(PoemPage::new(page_number));
        self.current_page = self.pages.len() - 1;
        page_number
    }
    
    pub fn get_current_page(&self) -> Option<&PoemPage> {
        self.pages.get(self.current_page)
    }
    
    pub fn get_current_page_mut(&mut self) -> Option<&mut PoemPage> {
        self.pages.get_mut(self.current_page)
    }
    
    pub fn next_page(&mut self) -> bool {
        if self.current_page < self.pages.len() - 1 {
            self.current_page += 1;
            true
        } else {
            false
        }
    }
    
    pub fn prev_page(&mut self) -> bool {
        if self.current_page > 0 {
            self.current_page -= 1;
            true
        } else {
            false
        }
    }
}

// ============================================================================
// CPUX - COMPUTATIONAL PATH
// ============================================================================

pub struct PoemWriterCPUX {
    pub id: String,
    pub collection: Arc<Mutex<PoemCollection>>,
    pub design_nodes: Vec<DesignNode>,
    pub objects: Vec<ObjectMapping>,
    pub network_field: Arc<Mutex<Vec<FieldPulse>>>,
}

impl PoemWriterCPUX {
    pub fn new() -> Self {
        let collection = Arc::new(Mutex::new(PoemCollection::new()));
        
        // Define Design Nodes (computation points)
        let design_nodes = vec![
            DesignNode::new("validate_poem", "Validate Poem Text", |inputs| {
                if let Some(pulse) = inputs.first() {
                    let empty = String::new();
                    let text = pulse.response.first().unwrap_or(&empty);
                    // Validation logic: check length, trim, etc.
                    let validated = text.trim().to_string();
                    if validated.len() > 10000 {
                        vec!["error_too_long".to_string()]
                    } else {
                        vec![validated]
                    }
                } else {
                    vec!["error_no_input".to_string()]
                }
            }),
            DesignNode::new("validate_notes", "Validate Notes Text", |inputs| {
                if let Some(pulse) = inputs.first() {
                    let empty = String::new();
                    let text = pulse.response.first().unwrap_or(&empty);
                    // Validation logic
                    let validated = text.trim().to_string();
                    if validated.len() > 5000 {
                        vec!["error_too_long".to_string()]
                    } else {
                        vec![validated]
                    }
                } else {
                    vec!["error_no_input".to_string()]
                }
            }),
            DesignNode::new("update_poem", "Update Poem Text", |inputs| {
                if let Some(pulse) = inputs.first() {
                    vec![pulse.response.first().unwrap_or(&String::new()).clone()]
                } else {
                    vec![]
                }
            }),
            DesignNode::new("update_notes", "Update Notes Text", |inputs| {
                if let Some(pulse) = inputs.first() {
                    vec![pulse.response.first().unwrap_or(&String::new()).clone()]
                } else {
                    vec![]
                }
            }),
            DesignNode::new("create_page", "Create New Page", |_inputs| {
                vec!["new_page_created".to_string()]
            }),
            DesignNode::new("navigate", "Navigate Pages", |inputs| {
                if let Some(pulse) = inputs.first() {
                    vec![pulse.response.first().unwrap_or(&"current".to_string()).clone()]
                } else {
                    vec![]
                }
            }),
        ];
        
        // Define Object Mappings (transformations)
        // CRITICAL: Objects map intentions but NEVER change the payload
        let objects = vec![
            ObjectMapping::new("reflect_validation_result", |pulse| {
                // Object examines payload and maps to different intentions
                // PAYLOAD REMAINS UNCHANGED
                let empty = String::new();
                let result = pulse.response.first().unwrap_or(&empty);
                if result.starts_with("error_") {
                    // Map to error intention - payload unchanged
                    FieldPulse::new("validation_error")
                        .with_response(pulse.response.clone())  // Same payload!
                        .with_tv(TV::N)
                } else {
                    // Map to success intention - payload unchanged
                    FieldPulse::new("validation_success")
                        .with_response(pulse.response.clone())  // Same payload!
                        .with_tv(TV::Y)
                }
            }),
            ObjectMapping::new("route_to_validation", |pulse| {
                // Object routes to validation - payload unchanged
                FieldPulse::new("ready_for_validation")
                    .with_response(pulse.response.clone())  // Same payload!
                    .with_tv(TV::U)
            }),
        ];
        
        Self {
            id: "poem_writer_cpux".to_string(),
            collection,
            design_nodes,
            objects,
            network_field: Arc::new(Mutex::new(Vec::new())),
        }
    }
    
    /// I-O-I-DN-I-O-I-DN-I-GL-I Flow: Update poem text
    /// Correct flow: Intention → Object → Intention → Design Node → Intention → Object → Intention → Design Node → Grid Lookout
    /// CRITICAL: Objects map intentions but NEVER change payload
    pub fn update_poem_text(&self, text: String) {
        // Intention 1: User input
        let intention1 = FieldPulse::new("user_input_poem")
            .with_response(vec![text.clone()])
            .with_tv(TV::U);
        
        // Object 1: Route to validation (payload unchanged)
        let object1 = self.objects.iter()
            .find(|o| o.id == "route_to_validation")
            .unwrap();
        let intention2 = object1.apply(&intention1);
        // intention2.response == intention1.response (UNCHANGED)
        
        // Design Node 1: Validate (COMPUTATION - can change payload)
        let dn1 = self.design_nodes.iter()
            .find(|d| d.id == "validate_poem")
            .unwrap();
        let intention3 = dn1.execute(&[intention2]);
        // intention3.response may differ (trimmed, or error)
        
        // Object 2: Map to different intentions based on payload examination
        // CRITICAL: Payload remains unchanged
        let object2 = self.objects.iter()
            .find(|o| o.id == "reflect_validation_result")
            .unwrap();
        let intention4 = object2.apply(&intention3);
        // intention4.response == intention3.response (UNCHANGED)
        // Only intention NAME and TV change
        
        // Check if validation succeeded
        if intention4.tv == TV::Y {
            // Design Node 2: Update state (COMPUTATION)
            let dn2 = self.design_nodes.iter()
                .find(|d| d.id == "update_poem")
                .unwrap();
            let intention5 = dn2.execute(&[intention4]);
            
            // Update model
            if let Ok(mut collection) = self.collection.lock() {
                if let Some(page) = collection.get_current_page_mut() {
                    page.update_poem(text);
                }
            }
            
            // Store in Network Field
            if let Ok(mut field) = self.network_field.lock() {
                field.push(intention5);
            }
        } else {
            // Validation failed - store error
            if let Ok(mut field) = self.network_field.lock() {
                field.push(intention4);
            }
        }
    }
    
    /// I-O-I-DN-I-O-I-DN-I-GL-I Flow: Update notes text
    /// CRITICAL: Objects map intentions but NEVER change payload
    pub fn update_notes_text(&self, text: String) {
        // Intention 1: User input
        let intention1 = FieldPulse::new("user_input_notes")
            .with_response(vec![text.clone()])
            .with_tv(TV::U);
        
        // Object 1: Route to validation (payload unchanged)
        let object1 = self.objects.iter()
            .find(|o| o.id == "route_to_validation")
            .unwrap();
        let intention2 = object1.apply(&intention1);
        
        // Design Node 1: Validate (COMPUTATION - can change payload)
        let dn1 = self.design_nodes.iter()
            .find(|d| d.id == "validate_notes")
            .unwrap();
        let intention3 = dn1.execute(&[intention2]);
        
        // Object 2: Map to different intentions (payload unchanged)
        let object2 = self.objects.iter()
            .find(|o| o.id == "reflect_validation_result")
            .unwrap();
        let intention4 = object2.apply(&intention3);
        
        // Check validation result
        if intention4.tv == TV::Y {
            // Design Node 2: Update state (COMPUTATION)
            let dn2 = self.design_nodes.iter()
                .find(|d| d.id == "update_notes")
                .unwrap();
            let intention5 = dn2.execute(&[intention4]);
            
            // Update model
            if let Ok(mut collection) = self.collection.lock() {
                if let Some(page) = collection.get_current_page_mut() {
                    page.update_notes(text);
                }
            }
            
            // Store in Network Field
            if let Ok(mut field) = self.network_field.lock() {
                field.push(intention5);
            }
        } else {
            // Validation failed
            if let Ok(mut field) = self.network_field.lock() {
                field.push(intention4);
            }
        }
    }
    
    /// Add new page
    pub fn add_page(&self) -> usize {
        let intention = FieldPulse::new("create_new_page")
            .with_tv(TV::U);
        
        let dn = self.design_nodes.iter()
            .find(|d| d.id == "create_page")
            .unwrap();
        let result = dn.execute(&[intention]);
        
        let page_number = if let Ok(mut collection) = self.collection.lock() {
            collection.add_page()
        } else {
            0
        };
        
        if let Ok(mut field) = self.network_field.lock() {
            field.push(result);
        }
        
        page_number
    }
    
    /// Navigate to next page
    pub fn next_page(&self) -> bool {
        if let Ok(mut collection) = self.collection.lock() {
            collection.next_page()
        } else {
            false
        }
    }
    
    /// Navigate to previous page
    pub fn prev_page(&self) -> bool {
        if let Ok(mut collection) = self.collection.lock() {
            collection.prev_page()
        } else {
            false
        }
    }
    
    /// Get current page data
    pub fn get_current_page(&self) -> Option<PoemPage> {
        if let Ok(collection) = self.collection.lock() {
            collection.get_current_page().cloned()
        } else {
            None
        }
    }
    
    /// Get page count
    pub fn get_page_count(&self) -> usize {
        if let Ok(collection) = self.collection.lock() {
            collection.pages.len()
        } else {
            0
        }
    }
    
    /// Get current page number
    pub fn get_current_page_number(&self) -> usize {
        if let Ok(collection) = self.collection.lock() {
            collection.current_page + 1
        } else {
            0
        }
    }
}

// ============================================================================
// SLINT INTEGRATION
// ============================================================================

slint::include_modules!();

pub fn main() {
    // Initialize CPUX
    let cpux = Arc::new(PoemWriterCPUX::new());
    
    // Create Slint UI
    let ui = PoemWriter::new().unwrap();
    
    // Initialize UI with first page
    if let Some(page) = cpux.get_current_page() {
        ui.set_poem_text(page.poem_text.into());
        ui.set_notes_text(page.notes_text.into());
        ui.set_page_number(page.page_number as i32);
        ui.set_total_pages(cpux.get_page_count() as i32);
    }
    
    // Connect UI callbacks to CPUX
    let cpux_clone = cpux.clone();
    ui.on_poem_text_changed(move |text| {
        cpux_clone.update_poem_text(text.to_string());
    });
    
    let cpux_clone = cpux.clone();
    ui.on_notes_text_changed(move |text| {
        cpux_clone.update_notes_text(text.to_string());
    });
    
    let cpux_clone = cpux.clone();
    let ui_weak = ui.as_weak();
    ui.on_add_page(move || {
        cpux_clone.add_page();
        if let Some(ui) = ui_weak.upgrade() {
            if let Some(page) = cpux_clone.get_current_page() {
                ui.set_poem_text(page.poem_text.into());
                ui.set_notes_text(page.notes_text.into());
                ui.set_page_number(page.page_number as i32);
                ui.set_total_pages(cpux_clone.get_page_count() as i32);
            }
        }
    });
    
    let cpux_clone = cpux.clone();
    let ui_weak = ui.as_weak();
    ui.on_next_page(move || {
        if cpux_clone.next_page() {
            if let Some(ui) = ui_weak.upgrade() {
                if let Some(page) = cpux_clone.get_current_page() {
                    ui.set_poem_text(page.poem_text.into());
                    ui.set_notes_text(page.notes_text.into());
                    ui.set_page_number(page.page_number as i32);
                    ui.set_total_pages(cpux_clone.get_page_count() as i32);
                }
            }
        }
    });
    
    let cpux_clone = cpux.clone();
    let ui_weak = ui.as_weak();
    ui.on_prev_page(move || {
        if cpux_clone.prev_page() {
            if let Some(ui) = ui_weak.upgrade() {
                if let Some(page) = cpux_clone.get_current_page() {
                    ui.set_poem_text(page.poem_text.into());
                    ui.set_notes_text(page.notes_text.into());
                    ui.set_page_number(page.page_number as i32);
                    ui.set_total_pages(cpux_clone.get_page_count() as i32);
                }
            }
        }
    });
    
    // Run the application
    ui.run().unwrap();
}
